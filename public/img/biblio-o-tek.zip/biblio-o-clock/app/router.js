import { Router } from 'express';
import { mainController } from './controllers/mainController.js';
import { authorController } from './controllers/authorController.js';

export const router = Router();

router.get('/', mainController.home);

router.get('/authors', authorController.authorList);
router.get('/authors/:id', authorController.authorDetails);
router.get('/authors/:id/books', authorController.authorBooks);
