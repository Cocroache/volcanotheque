import { readFileSync } from 'node:fs';
import path from 'node:path';

// Données lues dans les fichiers JSON : c'est ce que tu vas remplacer par PostgreSQL
const dataDir = path.join(import.meta.dirname, '..', '..', 'data');
const authors = JSON.parse(readFileSync(path.join(dataDir, 'authors.json'), 'utf8'));
const books = JSON.parse(readFileSync(path.join(dataDir, 'books.json'), 'utf8'));

export const authorController = {
  authorList(req, res) {
    res.render('authors', { authors });
  },

  authorDetails(req, res) {
    const id = Number(req.params.id);
    const author = authors.find((a) => a.id === id);
    if (!author) {
      return res.status(404).render('404');
    }
    res.render('author', { author });
  },

  authorBooks(req, res) {
    const id = Number(req.params.id);
    const author = authors.find((a) => a.id === id);
    if (!author) {
      return res.status(404).render('404');
    }
    const authorBooks = books.filter((b) => b.author_id === id);
    res.render('authorBooks', { author, books: authorBooks });
  },
};
