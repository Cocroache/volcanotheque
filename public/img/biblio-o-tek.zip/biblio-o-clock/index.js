import 'dotenv/config';
import path from 'node:path';
import express from 'express';
import { router } from './app/router.js';

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(import.meta.dirname, 'views'));

app.use(express.static(path.join(import.meta.dirname, 'public')));

app.use(router);

// Aucune route n'a répondu : page 404
app.use((req, res) => {
  res.status(404).render('404');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Biblio-o-clock sur http://localhost:${port}`);
});
