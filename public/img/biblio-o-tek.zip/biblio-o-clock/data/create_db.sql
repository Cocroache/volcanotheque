-- Biblio-o-clock : structure + données de départ
-- À lancer depuis la racine du projet avec psql et l'option qui exécute un fichier.

DROP TABLE IF EXISTS "book";
DROP TABLE IF EXISTS "author";

CREATE TABLE "author" (
  "id" SERIAL PRIMARY KEY,
  "first_name" VARCHAR(255) NOT NULL,
  "last_name" VARCHAR(255) NOT NULL,
  "nationality" VARCHAR(255)
);

CREATE TABLE "book" (
  "id" SERIAL PRIMARY KEY,
  "title" VARCHAR(255) NOT NULL,
  "year" INTEGER NOT NULL,
  "isbn" VARCHAR(20) NOT NULL UNIQUE,
  "author_id" INTEGER NOT NULL REFERENCES "author"("id")
);

INSERT INTO "author" ("first_name", "last_name", "nationality") VALUES
  ('Victor', 'Hugo', 'française'),
  ('Jules', 'Verne', 'française'),
  ('Albert', 'Camus', 'française'),
  ('Agatha', 'Christie', 'britannique'),
  ('Haruki', 'Murakami', 'japonaise'),
  ('Toni', 'Morrison', 'américaine'),
  ('Marguerite', 'Yourcenar', 'française');

INSERT INTO "book" ("title", "year", "isbn", "author_id") VALUES
  ('Notre-Dame de Paris', 1831, '978-2-0000-0001-1', 1),
  ('Les Misérables', 1862, '978-2-0000-0002-2', 1),
  ('Les Contemplations', 1856, '978-2-0000-0003-3', 1),
  ('Vingt mille lieues sous les mers', 1870, '978-2-0000-0004-4', 2),
  ('Le Tour du monde en quatre-vingts jours', 1872, '978-2-0000-0005-5', 2),
  ('L''Étranger', 1942, '978-2-0000-0006-6', 3),
  ('La Peste', 1947, '978-2-0000-0007-7', 3),
  ('La Chute', 1956, '978-2-0000-0008-8', 3),
  ('Le Crime de l''Orient-Express', 1934, '978-2-0000-0009-9', 4),
  ('La Nuit qui ne finit pas', 1967, '978-2-0000-0010-0', 4),
  ('Kafka sur le rivage', 2002, '978-2-0000-0011-1', 5),
  ('Le Passage de la nuit', 2004, '978-2-0000-0012-2', 5),
  ('Beloved', 1987, '978-2-0000-0013-3', 6),
  ('L''Œil le plus bleu', 1970, '978-2-0000-0014-4', 6);
