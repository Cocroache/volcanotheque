# Biblio-o-clock

Starter du devoir pratique n°3. L'énoncé complet est sur la page du devoir.

## Lancement

1. Créer un utilisateur et une base PostgreSQL `biblio` (voir partie 0 du devoir).
2. Exécuter `data/create_db.sql` sur cette base, depuis la racine du projet.
3. `npm install`
4. Créer un `.env` à partir de `.env.example`.
5. `npm run dev` (développement) ou `npm run start` (production).

## Ce qui est fourni

- Une appli Express qui marche déjà, mais lit ses données dans `data/authors.json` et `data/books.json`.
- Les vues EJS de départ (`views/`) et le CSS (`public/css/style.css`).
- Deux maquettes HTML à transformer en vues : `integration/add_book.html` (partie 3) et `integration/books.html` (bonus).

Le projet est en ES Modules (`"type": "module"` dans le `package.json`) : on utilise `import` / `export`, comme dans tes fiches.
